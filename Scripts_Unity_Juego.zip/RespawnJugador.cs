// Permite usar las herramientas de Unity: objetos, posiciones, teclas y componentes.
using UnityEngine;

// Define el componente que podremos colocar en un objeto de Unity.
public class RespawnJugador : MonoBehaviour
{
    // Guarda la posición de reaparición (X, Y, Z); inicialmente será el lugar donde empieza el jugador.
    private Vector3 checkpoint;
    // Guarda el componente que mueve al jugador y comprueba el contacto con el suelo.
    private CharacterController controller;

    // Unity ejecuta Start una vez antes de la primera actualización del componente habilitado: prepara los datos iniciales.
    void Start()
    {
        // Recuerda la posición inicial del jugador como primer punto de reaparición.
        checkpoint = transform.position;
        // Busca el Character Controller en este mismo objeto y guarda su referencia.
        controller = GetComponent<CharacterController>();
    }

    // Método público que otros scripts pueden llamar pasando una posición nueva.
    public void GuardarCheckpoint(Vector3 posicion)
    {
        // Sustituye el punto anterior por la posición recibida.
        checkpoint = posicion;
        // Escribe una confirmación en Console para comprobar que se ha guardado el checkpoint.
        Debug.Log("Checkpoint guardado");
    }

    // Método público que los obstáculos llaman para devolver al jugador al punto guardado.
    public void Reaparecer()
    {
        // Desactiva temporalmente el Character Controller antes de cambiar la posición directamente.
        controller.enabled = false;
        // Teletransporta al jugador al punto de reaparición guardado.
        transform.position = checkpoint;
        // Reactiva el Character Controller para poder seguir jugando.
        controller.enabled = true;
    }
}
