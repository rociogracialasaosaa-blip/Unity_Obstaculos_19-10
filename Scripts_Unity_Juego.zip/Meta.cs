// Permite usar las herramientas de Unity: objetos, posiciones, teclas y componentes.
using UnityEngine;

// Define el componente que podremos colocar en un objeto de Unity.
public class Meta : MonoBehaviour
{
    // Referencia al panel de victoria: arrastra PanelVictoria desde Hierarchy a esta casilla del Inspector.
    public GameObject panelVictoria;

    // Unity ejecuta Start una vez antes de la primera actualización del componente habilitado: prepara los datos iniciales.
    void Start()
    {
        // Oculta el panel al empezar.
        panelVictoria.SetActive(false);
    }

    // Unity lo llama cuando otro collider entra en esta zona trigger; other identifica al objeto que entra.
    void OnTriggerEnter(Collider other)
    {
        // Solo actúa si el objeto que entra tiene el tag Player; ignora los demás.
        if (other.CompareTag("Player"))
        {
            // Muestra el panel y sus hijos, incluido el texto de victoria.
            panelVictoria.SetActive(true);

            // Prepara una referencia al script que controla el movimiento del jugador.
            MovimientoJugador movimiento =
                // Busca el componente MovimientoJugador en el objeto que ha entrado.
                other.GetComponent<MovimientoJugador>();

            // Comprueba que encontró el componente antes de intentar desactivarlo.
            if (movimiento != null)
            {
                // Desactiva el script de movimiento: el jugador deja de caminar, saltar y controlar la cámara.
                movimiento.enabled = false;
            }
        }
    }
}
