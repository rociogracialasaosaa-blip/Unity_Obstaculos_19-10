// OBSTÁCULO MORTAL
// Colocar en el obstáculo con Is Trigger activado. El jugador necesita tag Player y RespawnJugador.
// Código original: Aitor López Gómez (https://github.com/Aitor-Lopez-Gomez/ClaseUnity).
// Comentarios didácticos en español. Se conserva la lógica original.
// Las llaves { } delimitan bloques; ; termina instrucciones. Los comentarios // no se ejecutan.

// Permite usar las herramientas de Unity: objetos, posiciones, teclas y componentes.
using UnityEngine;

// Define el componente que podremos colocar en un objeto de Unity. MonoBehaviour lo conecta con Unity.
public class ObstaculoMortal : MonoBehaviour
{
    // Unity lo llama cuando otro collider entra en esta zona trigger; other identifica al objeto que entra.
    void OnTriggerEnter(Collider other)
    {
        // Solo actúa si el objeto que entra tiene el tag Player; ignora los demás.
        if (other.CompareTag("Player"))
        {
            // Busca RespawnJugador en el jugador. Debe tenerlo añadido para que esto funcione.
            other.GetComponent<RespawnJugador>().Reaparecer();
        }
    }
}
