# Scripts de Unity comentados

Código original: Aitor López Gómez — https://github.com/Aitor-Lopez-Gomez/ClaseUnity
Comentarios didácticos en español para trabajar en clase.

## Importación
Extrae este ZIP y arrastra los cinco archivos .cs a Assets/MisScripts en Unity. No importes también otra copia de las mismas clases.

El archivo Movimiento.cs del ZIP original se llama aquí MovimientoJugador.cs para coincidir con la clase. Si tu proyecto ya tiene Movimiento.cs con esa misma clase, reemplaza su contenido por el comentado y renómbralo desde Unity, o conserva tu copia funcional: no añadas una segunda clase MovimientoJugador. No se ha cambiado la lógica de los scripts.

## Configuración
- Jugador: tag Player, Character Controller, MovimientoJugador y RespawnJugador. Asigna Main Camera al campo Camara (también puede encontrarla por el tag MainCamera).
- Entrada: estos scripts usan Input.GetAxis. Configura Active Input Handling en Both o Input Manager (Old).
- Obstáculo: Box Collider con Is Trigger y ObstaculoMortal.
- Checkpoint opcional: zona con Is Trigger y Checkpoint; su posición será el punto de reaparición. Colócala para que el jugador reaparezca sin quedar dentro del suelo.
- Meta: zona con Is Trigger y una sola copia de Meta. Arrastra PanelVictoria a Panel Victoria en el Inspector.
- PanelVictoria: dentro de un Canvas activo; texto de victoria como hijo. El script lo oculta al empezar y lo muestra al ganar.
- Suelo y camino normales: mantén sus colliders sólidos, sin Is Trigger.

## Prueba
Comprueba en Play el movimiento, salto, vuelta al inicio al tocar el obstáculo y panel al llegar a la meta. Estos archivos no incluyen escena, cámara ni panel ya creados.
